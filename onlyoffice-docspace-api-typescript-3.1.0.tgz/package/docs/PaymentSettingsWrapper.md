# PaymentSettingsWrapper


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | [**PaymentSettingsDto**](PaymentSettingsDto.md) |  | [optional] [default to undefined]
**count** | **number** |  | [optional] [default to undefined]
**links** | [**Array&lt;ActiveConnectionsWrapperLinksInner&gt;**](ActiveConnectionsWrapperLinksInner.md) |  | [optional] [default to undefined]
**status** | **number** |  | [optional] [default to undefined]
**statusCode** | **number** |  | [optional] [default to undefined]

## Example

```typescript
import { PaymentSettingsWrapper } from '@onlyoffice/docspace-api-typescript';

const instance: PaymentSettingsWrapper = {
    response,
    count,
    links,
    status,
    statusCode,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
