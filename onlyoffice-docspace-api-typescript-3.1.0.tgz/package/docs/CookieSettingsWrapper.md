# CookieSettingsWrapper


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response** | [**CookieSettingsDto**](CookieSettingsDto.md) |  | [optional] [default to undefined]
**count** | **number** |  | [optional] [default to undefined]
**links** | [**Array&lt;ActiveConnectionsWrapperLinksInner&gt;**](ActiveConnectionsWrapperLinksInner.md) |  | [optional] [default to undefined]
**status** | **number** |  | [optional] [default to undefined]
**statusCode** | **number** |  | [optional] [default to undefined]

## Example

```typescript
import { CookieSettingsWrapper } from '@onlyoffice/docspace-api-typescript';

const instance: CookieSettingsWrapper = {
    response,
    count,
    links,
    status,
    statusCode,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
